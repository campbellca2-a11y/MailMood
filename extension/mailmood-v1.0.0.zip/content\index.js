// src/constants.ts
var TONE_META = {
  calm_professional: { label: "Calm / Professional", color: "#2e7d32" },
  warm_positive: { label: "Warm / Positive", color: "#ef6c00" },
  urgent_tense: { label: "Urgent / Tense", color: "#c62828" },
  apologetic_anxious: { label: "Apologetic / Anxious", color: "#6a1b9a" },
  neutral_automated: { label: "Neutral / Automated", color: "#607d8b" },
  sad_concerned: { label: "Sad / Concerned", color: "#1565c0" }
};
var SELECTORS = {
  inboxRow: "tr.zA",
  subject: "span.bog",
  preview: "span.y2",
  composeBody: "div[role='textbox'][g_editable='true']",
  composeDialog: "div[role='dialog']"
};

// src/content/composePanel.ts
var contexts = /* @__PURE__ */ new Map();
function sendAnalyze(text) {
  const message = {
    type: "MM_ANALYZE",
    payload: { text, mode: "outgoing" }
  };
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
        return;
      }
      if (!response?.ok) {
        reject(new Error(response?.error ?? "Unknown background error"));
        return;
      }
      resolve(response.data);
    });
  });
}
function sendRewrite(text, targetTone) {
  const message = {
    type: "MM_REWRITE",
    payload: { text, targetTone }
  };
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
        return;
      }
      if (!response?.ok) {
        reject(new Error(response?.error ?? "Unknown background error"));
        return;
      }
      resolve(response.data);
    });
  });
}
function getDraftText(body) {
  return body.innerText.trim();
}
function renderAnalysis(context, analysis) {
  const meta = TONE_META[analysis.toneLabel];
  context.status.textContent = `${meta.label} (${Math.round(analysis.confidence * 100)}%)`;
  context.status.style.color = meta.color;
  context.status.title = analysis.explanation;
  context.emotionList.innerHTML = "";
  analysis.emotions.forEach((emotion) => {
    const item = document.createElement("li");
    item.textContent = `${emotion.name}: ${Math.round(emotion.intensity * 100)}%`;
    context.emotionList.appendChild(item);
  });
}
function setRewriteLoading(context, loading) {
  context.rewriteButton.disabled = loading;
  context.rewriteButton.textContent = loading ? "Rewriting..." : "Rewrite";
}
function hideRewritePreview(context) {
  context.rewritePreview.hidden = true;
  context.rewriteText.textContent = "";
}
function showRewritePreview(context, rewrite) {
  context.rewriteText.textContent = rewrite.rewritten;
  context.rewritePreview.hidden = false;
}
function makeDraggable(panel, handle) {
  let offsetX = 0;
  let offsetY = 0;
  let dragging = false;
  handle.addEventListener("mousedown", (e) => {
    if (e.target.closest(".mm-toggle")) {
      return;
    }
    dragging = true;
    offsetX = e.clientX - panel.getBoundingClientRect().left;
    offsetY = e.clientY - panel.getBoundingClientRect().top;
    e.preventDefault();
  });
  document.addEventListener("mousemove", (e) => {
    if (!dragging) return;
    panel.style.left = `${e.clientX - offsetX}px`;
    panel.style.top = `${e.clientY - offsetY}px`;
    panel.style.right = "auto";
    panel.style.bottom = "auto";
  });
  document.addEventListener("mouseup", () => {
    dragging = false;
  });
}
function createPanel() {
  const panel = document.createElement("div");
  panel.className = "mm-compose-panel";
  panel.innerHTML = `
    <div class="mm-header">
      <span class="mm-title">MailMood</span>
      <button class="mm-toggle" type="button" title="Minimize">_</button>
    </div>
    <div class="mm-panel-body">
      <div class="mm-status">Analyzing draft...</div>
      <ul class="mm-emotions"></ul>
      <div class="mm-actions">
        <button class="mm-btn mm-btn-primary mm-rewrite-btn" type="button">Rewrite</button>
        <button class="mm-btn mm-btn-muted mm-send-anyway-btn" type="button">Send Anyway</button>
      </div>
      <div class="mm-rewrite-preview" hidden>
        <div class="mm-rewrite-label">Suggested rewrite</div>
        <pre class="mm-rewrite-text"></pre>
        <div class="mm-actions">
          <button class="mm-btn mm-btn-primary mm-apply-rewrite-btn" type="button">Apply Rewrite</button>
          <button class="mm-btn mm-btn-muted mm-dismiss-rewrite-btn" type="button">Dismiss</button>
        </div>
      </div>
      <p class="mm-caption">No email text is stored.</p>
    </div>
  `;
  const header = panel.querySelector(".mm-header");
  const panelBody = panel.querySelector(".mm-panel-body");
  const toggleBtn = panel.querySelector(".mm-toggle");
  const status = panel.querySelector(".mm-status");
  const emotionList = panel.querySelector(".mm-emotions");
  const rewriteButton = panel.querySelector(".mm-rewrite-btn");
  const sendAnywayButton = panel.querySelector(".mm-send-anyway-btn");
  const rewritePreview = panel.querySelector(".mm-rewrite-preview");
  const rewriteText = panel.querySelector(".mm-rewrite-text");
  const applyRewriteButton = panel.querySelector(".mm-apply-rewrite-btn");
  const dismissRewriteButton = panel.querySelector(".mm-dismiss-rewrite-btn");
  makeDraggable(panel, header);
  toggleBtn.addEventListener("click", () => {
    const isHidden = panelBody.style.display === "none";
    panelBody.style.display = isHidden ? "" : "none";
    toggleBtn.textContent = isHidden ? "_" : "+";
    toggleBtn.title = isHidden ? "Minimize" : "Expand";
    panel.classList.toggle("mm-minimized", !isHidden);
  });
  return {
    body: document.createElement("div"),
    panel,
    panelBody,
    status,
    emotionList,
    rewriteButton,
    sendAnywayButton,
    rewritePreview,
    rewriteText,
    applyRewriteButton,
    dismissRewriteButton,
    lastDraft: "",
    lastAnalysis: null,
    timerId: null
  };
}
async function updateAnalysis(context) {
  const text = getDraftText(context.body);
  if (text.length < 6 || text === context.lastDraft) {
    return;
  }
  context.lastDraft = text;
  hideRewritePreview(context);
  context.status.textContent = "Analyzing...";
  try {
    const analysis = await sendAnalyze(text);
    context.lastAnalysis = analysis;
    renderAnalysis(context, analysis);
  } catch {
    context.lastAnalysis = null;
    context.status.textContent = "Tone unavailable.";
  }
}
async function runRewrite(context) {
  const text = getDraftText(context.body);
  if (!text) {
    return;
  }
  const detectedTone = context.lastAnalysis?.toneLabel ?? "calm_professional";
  const targetTone = detectedTone === "urgent_tense" || detectedTone === "apologetic_anxious" ? "calm_professional" : "warm_positive";
  setRewriteLoading(context, true);
  try {
    const rewrite = await sendRewrite(text, targetTone);
    showRewritePreview(context, rewrite);
  } catch {
    context.status.textContent = "Rewrite unavailable.";
  } finally {
    setRewriteLoading(context, false);
  }
}
function attachToComposeBody(body) {
  if (contexts.has(body)) {
    return;
  }
  const dialog = body.closest(SELECTORS.composeDialog);
  if (!dialog) {
    return;
  }
  const context = createPanel();
  context.body = body;
  contexts.set(body, context);
  document.body.appendChild(context.panel);
  const dialogRect = dialog.getBoundingClientRect();
  context.panel.style.top = `${dialogRect.top + 10}px`;
  context.panel.style.left = `${dialogRect.right + 8}px`;
  const panelWidth = 280;
  if (dialogRect.right + panelWidth + 16 > window.innerWidth) {
    context.panel.style.left = `${Math.max(8, dialogRect.left - panelWidth - 8)}px`;
  }
  const schedule = () => {
    if (context.timerId !== null) {
      window.clearTimeout(context.timerId);
    }
    context.timerId = window.setTimeout(() => {
      void updateAnalysis(context);
    }, 500);
  };
  context.rewriteButton.addEventListener("click", () => {
    void runRewrite(context);
  });
  context.sendAnywayButton.addEventListener("click", () => {
    hideRewritePreview(context);
    context.status.textContent = "Send decision remains yours.";
  });
  context.dismissRewriteButton.addEventListener("click", () => {
    hideRewritePreview(context);
  });
  context.applyRewriteButton.addEventListener("click", () => {
    const rewritten = context.rewriteText.textContent?.trim() ?? "";
    if (!rewritten) {
      return;
    }
    body.innerText = rewritten;
    body.dispatchEvent(new Event("input", { bubbles: true }));
    hideRewritePreview(context);
    context.status.textContent = "Rewrite applied.";
  });
  body.addEventListener("input", schedule, { passive: true });
  void updateAnalysis(context);
}
function cleanupOrphanedPanels() {
  for (const [body, context] of contexts) {
    if (!document.body.contains(body)) {
      if (context.timerId !== null) {
        window.clearTimeout(context.timerId);
      }
      context.panel.remove();
      contexts.delete(body);
    }
  }
}
function scanComposeBodies() {
  cleanupOrphanedPanels();
  const bodies = document.querySelectorAll(SELECTORS.composeBody);
  bodies.forEach((body) => attachToComposeBody(body));
}
function initComposeWatcher() {
  scanComposeBodies();
  let rafId = 0;
  const observer = new MutationObserver(() => {
    if (rafId) {
      cancelAnimationFrame(rafId);
    }
    rafId = requestAnimationFrame(scanComposeBodies);
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

// src/content/inbox.ts
var toneCache = /* @__PURE__ */ new Map();
var MAX_CACHE_SIZE = 200;
function setCached(key, value) {
  if (toneCache.size >= MAX_CACHE_SIZE) {
    const firstKey = toneCache.keys().next().value;
    if (firstKey !== void 0) toneCache.delete(firstKey);
  }
  toneCache.set(key, value);
}
function digest(text) {
  let hash = 0;
  for (let i = 0; i < text.length; i += 1) {
    hash = (hash << 5) - hash + text.charCodeAt(i);
    hash |= 0;
  }
  return `${hash}`;
}
function sendAnalyze2(text) {
  const message = {
    type: "MM_ANALYZE",
    payload: { text, mode: "incoming" }
  };
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
        return;
      }
      if (!response?.ok) {
        reject(new Error(response?.error ?? "Unknown background error"));
        return;
      }
      resolve(response.data);
    });
  });
}
function upsertMoodBadge(subjectEl, analysis) {
  const meta = TONE_META[analysis.toneLabel];
  const host = subjectEl.parentElement;
  if (!host) {
    return;
  }
  let badge = host.querySelector(".mm-inbox-badge");
  if (!badge) {
    badge = document.createElement("span");
    badge.className = "mm-inbox-badge";
    badge.addEventListener("mousedown", (e) => {
      e.stopPropagation();
    });
    badge.addEventListener("click", (e) => {
      e.stopPropagation();
    });
    host.appendChild(badge);
  }
  badge.textContent = meta.label;
  badge.style.backgroundColor = `${meta.color}1A`;
  badge.style.color = meta.color;
  badge.style.borderColor = `${meta.color}55`;
  badge.title = `${meta.label} (${Math.round(analysis.confidence * 100)}%) - ${analysis.explanation}`;
}
var pending = /* @__PURE__ */ new Set();
var MAX_CONCURRENT = 5;
var activeCount = 0;
var analysisQueue = [];
function drainQueue() {
  while (activeCount < MAX_CONCURRENT && analysisQueue.length > 0) {
    const next = analysisQueue.shift();
    if (next) next();
  }
}
function withConcurrencyLimit(fn) {
  if (activeCount < MAX_CONCURRENT) {
    activeCount++;
    fn().finally(() => {
      activeCount--;
      drainQueue();
    });
  } else {
    analysisQueue.push(() => {
      activeCount++;
      fn().finally(() => {
        activeCount--;
        drainQueue();
      });
    });
  }
}
async function analyzeRow(row) {
  const subjectEl = row.querySelector(SELECTORS.subject);
  const previewEl = row.querySelector(SELECTORS.preview);
  if (!subjectEl) {
    return;
  }
  const subject = subjectEl.textContent?.trim() ?? "";
  const preview = previewEl?.textContent?.trim().replace(/^-\s*/, "") ?? "";
  const text = `${subject}. ${preview}`.trim();
  if (!text || text === ".") {
    return;
  }
  const hash = digest(text);
  if (subjectEl.parentElement?.querySelector(".mm-inbox-badge")) {
    return;
  }
  const cached = toneCache.get(hash);
  if (cached) {
    upsertMoodBadge(subjectEl, cached);
    return;
  }
  if (pending.has(hash)) {
    return;
  }
  pending.add(hash);
  try {
    const analysis = await sendAnalyze2(text);
    setCached(hash, analysis);
    const freshSubject = row.querySelector(SELECTORS.subject);
    if (freshSubject) {
      upsertMoodBadge(freshSubject, analysis);
    }
  } catch {
  } finally {
    pending.delete(hash);
  }
}
var observerPaused = false;
function scanInbox() {
  observerPaused = true;
  const rows = document.querySelectorAll(SELECTORS.inboxRow);
  rows.forEach((row) => {
    withConcurrencyLimit(() => analyzeRow(row));
  });
  queueMicrotask(() => {
    observerPaused = false;
  });
}
function initInboxWatcher() {
  scanInbox();
  let rafId = 0;
  const observer = new MutationObserver((mutations) => {
    if (observerPaused) return;
    const isOwnMutation = mutations.every(
      (m) => Array.from(m.addedNodes).every(
        (n) => n instanceof HTMLElement && n.classList.contains("mm-inbox-badge")
      )
    );
    if (isOwnMutation) return;
    if (rafId) {
      cancelAnimationFrame(rafId);
    }
    rafId = requestAnimationFrame(() => {
      scanInbox();
    });
  });
  observer.observe(document.body, { subtree: true, childList: true });
}

// src/content/index.ts
var HEALTH_CHECK_DELAY_MS = 4e3;
function runHealthCheck() {
  const rows = document.querySelectorAll(SELECTORS.inboxRow);
  if (rows.length > 0) return;
  const existing = document.getElementById("mm-health-warning");
  if (existing) return;
  const warning = document.createElement("div");
  warning.id = "mm-health-warning";
  warning.title = "MailMood: Gmail's layout may have changed. Mood badges are currently unavailable.";
  warning.style.cssText = [
    "position:fixed",
    "bottom:16px",
    "right:16px",
    "z-index:99999",
    "background:#b71c1c",
    "color:#fff",
    "font-size:12px",
    "font-family:Google Sans,Roboto,sans-serif",
    "font-weight:600",
    "padding:8px 14px",
    "border-radius:8px",
    "box-shadow:0 4px 12px rgba(0,0,0,0.3)",
    "cursor:pointer",
    "user-select:none"
  ].join(";");
  warning.textContent = "\u26A0\uFE0F MailMood: Gmail layout changed \u2014 badges unavailable";
  warning.addEventListener("click", () => warning.remove());
  document.body.appendChild(warning);
  setTimeout(() => warning.remove(), 1e4);
}
function bootstrap() {
  initInboxWatcher();
  initComposeWatcher();
  setTimeout(runHealthCheck, HEALTH_CHECK_DELAY_MS);
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", bootstrap, { once: true });
} else {
  bootstrap();
}
